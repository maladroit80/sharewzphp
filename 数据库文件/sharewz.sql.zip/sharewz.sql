-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2010 年 04 月 30 日 07:48
-- 服务器版本: 5.1.33
-- PHP 版本: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `sharewz`
--

-- --------------------------------------------------------

--
-- 表的结构 `memberp2c`
--

CREATE TABLE IF NOT EXISTS `memberp2c` (
  `UserName` varchar(200) DEFAULT NULL,
  `P2CID` int(11) DEFAULT NULL,
  `P2CDate` varchar(200) DEFAULT NULL,
  `P2CScreen` varchar(200) DEFAULT NULL,
  `P2CIP` varchar(50) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 导出表中的数据 `memberp2c`
--


-- --------------------------------------------------------

--
-- 表的结构 `p2c`
--

CREATE TABLE IF NOT EXISTS `p2c` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `P2CName` varchar(200) DEFAULT NULL,
  `P2CLink` varchar(50) DEFAULT NULL,
  `P2CImg` varchar(200) DEFAULT NULL,
  `P2CText` varchar(200) DEFAULT NULL,
  `P2CType` varchar(50) DEFAULT NULL,
  `P2CTime` int(11) DEFAULT NULL,
  `P2CValuation` float DEFAULT NULL,
  `P2CVisit` int(11) DEFAULT NULL,
  `P2CLimit` int(11) DEFAULT NULL,
  `P2CTarget` varchar(150) DEFAULT NULL,
  `P2COwner` varchar(150) DEFAULT NULL,
  `P2CValid` tinyint(1) DEFAULT '1',
  `NeedClick` int(11) DEFAULT NULL,
  `P2CClick` int(11) DEFAULT NULL,
  `P2CRate` double DEFAULT NULL,
  `P2CGroup` varchar(100) DEFAULT NULL,
  `P2CTotalVisit` int(11) DEFAULT NULL,
  `P2CTotalClick` int(11) DEFAULT NULL,
  `MemberPriority` int(11) DEFAULT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 导出表中的数据 `p2c`
--

INSERT INTO `p2c` (`id`, `P2CName`, `P2CLink`, `P2CImg`, `P2CText`, `P2CType`, `P2CTime`, `P2CValuation`, `P2CVisit`, `P2CLimit`, `P2CTarget`, `P2COwner`, `P2CValid`, `NeedClick`, `P2CClick`, `P2CRate`, `P2CGroup`, `P2CTotalVisit`, `P2CTotalClick`, `MemberPriority`) VALUES
(1, 'P2C_123', 'http://www.sharewz.com', NULL, 'dstest', 'Dollars', 30, 0.005, 0, 0, 'Normal', '请在后台设置', 1, -1, 0, 1, '公告', 0, 1000, 0),
(2, 'P2C_236', 'http://www.sharewz.com', NULL, 'dstest2222', 'Dollars', 30, 0.005, 0, 0, 'Normal', '请在后台设置', 1, -1, 0, 1, '公告', 0, 1000, 0),
(3, 'P2C_666', 'http://www.sharewz.com', NULL, 'dstest333', 'Dollars', 30, 0.005, 0, 0, 'Normal', '请在后台设置', 1, -1, 0, 1, '公告', 0, 1000, 0);

-- --------------------------------------------------------

--
-- 表的结构 `tb_ads`
--

CREATE TABLE IF NOT EXISTS `tb_ads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(150) NOT NULL DEFAULT '',
  `ip` varchar(15) NOT NULL DEFAULT '',
  `tipo` varchar(150) NOT NULL DEFAULT '',
  `visitime` varchar(150) NOT NULL DEFAULT '',
  `ident` varchar(150) NOT NULL DEFAULT '',
  `fechainicia` varchar(150) NOT NULL DEFAULT '',
  `paypalname` varchar(150) NOT NULL DEFAULT '',
  `paypalemail` varchar(150) NOT NULL DEFAULT '',
  `plan` varchar(150) NOT NULL DEFAULT '',
  `bold` varchar(150) NOT NULL DEFAULT '',
  `highlight` varchar(150) NOT NULL DEFAULT '',
  `url` varchar(150) NOT NULL DEFAULT '',
  `description` varchar(150) NOT NULL DEFAULT '',
  `category` varchar(150) NOT NULL DEFAULT '',
  `members` varchar(150) NOT NULL DEFAULT '0',
  `outside` varchar(150) NOT NULL DEFAULT '0',
  `total` varchar(150) NOT NULL DEFAULT '0',
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- 导出表中的数据 `tb_ads`
--

INSERT INTO `tb_ads` (`id`, `user`, `ip`, `tipo`, `visitime`, `ident`, `fechainicia`, `paypalname`, `paypalemail`, `plan`, `bold`, `highlight`, `url`, `description`, `category`, `members`, `outside`, `total`) VALUES
(2, 'admin', '', 'visit', '1213866487', '1', '', '', '', '', '', '', '', '', '', '0', '0', '0'),
(4, 'admin', '', 'visit', '1213866845', '3', '', '', '', '', '', '', '', '', '', '0', '0', '0'),
(6, 'admin', '', 'visit', '1213867110', '5', '', '', '', '', '', '', '', '', '', '0', '0', '0'),
(9, 'admin', '', 'ads', '', '', '', '', '', '1000', '', '', 'http://www.sharewz.com', 'sharewz', '2', '0', '0', '0'),
(8, 'admin', '', 'ads', '', '', '', '', '', '1000', '', '', 'http://www.sharewz.com', 'http://www.sharewz.com', '1', '4', '2', '0'),
(11, 'admin', '', 'ads', '', '', '', '', '', '1000', '', '', 'http://www.sharewz.com', 'http://www.sharewz.com', '3', '0', '0', '0'),
(12, 'hilary43210', '', 'visit', '1259644281', '8', '', '', '', '', '', '', '', '', '', '0', '0', '0'),
(14, 'admin', '', 'ads', '', '', '', '', '', '1000', '', '', 'http://www.sharewz.com', 'share', '1', '0', '0', '0'),
(15, 'admin', '', 'visit', '1271061638', '8', '', '', '', '', '', '', '', '', '', '0', '0', '0'),
(16, '', '', 'ads', '', '', '1261724910', '', 'yehaihua111@126.com', '500', '', '', 'http://www.sharewz.com', '1111', '1', '2', '0', '0'),
(18, 'admin', '', 'visit', '1271059363', '16', '', '', '', '', '', '', '', '', '', '0', '0', '0'),
(19, 'admin', '', 'ads', '', '', '', '', '', '1000', '', '', 'http://www.sharewz.com', 'sharewz', '2', '0', '0', '0'),
(20, 'admin', '', 'ads', '', '', '', '', '', '1000', '', '', '', '', '1', '0', '0', '0');

-- --------------------------------------------------------

--
-- 表的结构 `tb_ads_categories`
--

CREATE TABLE IF NOT EXISTS `tb_ads_categories` (
  `id` int(11) NOT NULL DEFAULT '0',
  `catname` varchar(50) NOT NULL DEFAULT '',
  `click` float DEFAULT NULL,
  `referalclick` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 导出表中的数据 `tb_ads_categories`
--

INSERT INTO `tb_ads_categories` (`id`, `catname`, `click`, `referalclick`) VALUES
(1, '本站广告区', 0.005, 0.001),
(2, '包月广告区（20元/10秒）', 0.001, 0.0002),
(9, '20秒自助广告区（6元/1000ip）', 0.003, 0.0006),
(8, '25秒自助广告区（8元/1000ip）', 0.004, 0.0008),
(7, '30秒自助广告区（10元/1000ip）', 0.005, 0.0001),
(3, '包月广告区（25元/15秒）', 0.002, 0.0004),
(4, '包月广告区（30元/20秒）', 0.003, 0.0006),
(5, '包月广告区（35元/25秒）', 0.004, 0.0008),
(6, '包月广告区（40元/30秒）', 0.005, 0.001),
(10, '15秒自助广告区（4元/1000ip）', 0.002, 0.0004),
(11, '8秒自助广告区（2元/1000ip）', 0.001, 0.0002);

-- --------------------------------------------------------

--
-- 表的结构 `tb_advertisers`
--

CREATE TABLE IF NOT EXISTS `tb_advertisers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pname` varchar(150) NOT NULL DEFAULT '',
  `pemail` varchar(150) NOT NULL DEFAULT '',
  `plan` varchar(150) NOT NULL DEFAULT '',
  `url` varchar(150) NOT NULL DEFAULT '',
  `description` varchar(150) NOT NULL DEFAULT '',
  `category` varchar(150) NOT NULL DEFAULT '',
  `ip` varchar(15) NOT NULL DEFAULT '',
  `bold` varchar(150) NOT NULL DEFAULT '',
  `highlight` varchar(150) NOT NULL DEFAULT '',
  `tipo` varchar(150) NOT NULL DEFAULT '',
  `money` varchar(150) NOT NULL DEFAULT '',
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 导出表中的数据 `tb_advertisers`
--

INSERT INTO `tb_advertisers` (`id`, `pname`, `pemail`, `plan`, `url`, `description`, `category`, `ip`, `bold`, `highlight`, `tipo`, `money`) VALUES
(2, '', 'ddd', '500', 'http://dddd.com', 'ddd', '', '127.0.0.1', '', '', '', '');

-- --------------------------------------------------------

--
-- 表的结构 `tb_backpay_history`
--

CREATE TABLE IF NOT EXISTS `tb_backpay_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `pay_number` int(50) DEFAULT NULL,
  `pay_sum` double DEFAULT NULL,
  `pay_time` varchar(35) DEFAULT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=30 ;

--
-- 导出表中的数据 `tb_backpay_history`
--

INSERT INTO `tb_backpay_history` (`id`, `username`, `pay_number`, `pay_sum`, `pay_time`) VALUES
(29, 'admin', 1, 0.3, '2010-4-01 03:59'),
(28, 'hilary3210', 1, 0.9, '2010-4-01 03:58');

-- --------------------------------------------------------

--
-- 表的结构 `tb_back_account`
--

CREATE TABLE IF NOT EXISTS `tb_back_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `zhifubao` varchar(150) DEFAULT NULL,
  `now_back_sum` float DEFAULT NULL,
  `all_back_sum` float DEFAULT NULL,
  `back_pay_number` int(10) DEFAULT NULL,
  `back_pay_time` varchar(35) DEFAULT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=38 ;

--
-- 导出表中的数据 `tb_back_account`
--

INSERT INTO `tb_back_account` (`id`, `username`, `zhifubao`, `now_back_sum`, `all_back_sum`, `back_pay_number`, `back_pay_time`) VALUES
(33, 'hilary', 'ss@dd.com', 0, 1.2, 4, '2010-4-01 03:35'),
(37, 'admin', 'admin@wycy8.cn', 0.1, 0.3, 1, '2010-4-01 03:59'),
(36, 'hilary3210', 'ss@ss.com', 0, 0.9, 1, '2010-4-01 03:58');

-- --------------------------------------------------------

--
-- 表的结构 `tb_back_common`
--

CREATE TABLE IF NOT EXISTS `tb_back_common` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(150) NOT NULL DEFAULT '',
  `backname` varchar(150) NOT NULL DEFAULT '',
  `site_id` int(11) DEFAULT NULL,
  `site_name` varchar(150) DEFAULT NULL,
  `last_click` int(11) DEFAULT NULL,
  `pay_click` int(11) DEFAULT NULL,
  `current_click` int(11) DEFAULT NULL,
  `last_back` varchar(150) DEFAULT NULL,
  `pay_back` varchar(150) DEFAULT NULL,
  `current_back` varchar(150) DEFAULT NULL,
  `site_reg_status` varchar(150) DEFAULT NULL,
  `pay_status` varchar(150) DEFAULT NULL,
  `back_time` varchar(35) DEFAULT NULL,
  `site_reg_time` varchar(35) DEFAULT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=60 ;

--
-- 导出表中的数据 `tb_back_common`
--

INSERT INTO `tb_back_common` (`id`, `username`, `backname`, `site_id`, `site_name`, `last_click`, `pay_click`, `current_click`, `last_back`, `pay_back`, `current_back`, `site_reg_status`, `pay_status`, `back_time`, `site_reg_time`) VALUES
(1, 'hilary3210', 'hilary3210', 1, '快乐转转', 20, 1, 20, '2', '0.1', '2', '成功登记', '等待返佣', '10-04-01 03:57', '10-03-26 02:24'),
(2, 'hilary', 'hilary', 1, '1', 3, 1, 3, '0.2', '0.1', '0.2', '成功登记', '等待返佣', '10-03-31 09:14', '10-03-25 08:44'),
(3, '123', '123', 1, '快乐转转', 2, 2, 2, '0.2', '0.2', '0.2', '成功登记', '成功返佣', '10-03-31 09:14', '2010/03/23'),
(58, 'admin', 'admin', 1, '快乐转转', 4, 1, 4, '0.4', '0.1', '0.4', '等待登记', '等待返佣', '10-04-01 04:08', '10-04-01 03:59'),
(59, '', 'aaa', 2, '51诚信币', 0, 0, 0, '0', '0', '0', '等待登记', '成功返佣', '10-04-01 09:37', '10-04-01 09:37');

-- --------------------------------------------------------

--
-- 表的结构 `tb_back_history`
--

CREATE TABLE IF NOT EXISTS `tb_back_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(11) DEFAULT NULL,
  `site_id` int(11) DEFAULT NULL,
  `site_name` varchar(50) DEFAULT NULL,
  `pay_sum` float DEFAULT NULL,
  `back_number` int(10) DEFAULT NULL,
  `time` varchar(35) DEFAULT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- 导出表中的数据 `tb_back_history`
--


-- --------------------------------------------------------

--
-- 表的结构 `tb_back_site`
--

CREATE TABLE IF NOT EXISTS `tb_back_site` (
  `site_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_name` varchar(150) NOT NULL DEFAULT '',
  `click_value` float DEFAULT NULL,
  `site_money_unit` varchar(50) DEFAULT NULL,
  `refer_earn_per` float DEFAULT NULL,
  `back_percent` float DEFAULT NULL,
  `min_pay` float DEFAULT NULL,
  `site_pay_method` varchar(100) DEFAULT NULL,
  `max_refer_number` int(11) DEFAULT NULL,
  `now_refer_number` int(11) DEFAULT NULL,
  `back_number` int(11) DEFAULT NULL,
  `site_status` varchar(150) DEFAULT NULL,
  `site_category` varchar(150) DEFAULT NULL,
  `refer_link` varchar(150) DEFAULT NULL,
  `help_link` varchar(150) DEFAULT NULL,
  `site_comment` varchar(500) DEFAULT NULL,
  `site_time` varchar(35) DEFAULT NULL,
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- 导出表中的数据 `tb_back_site`
--

INSERT INTO `tb_back_site` (`site_id`, `site_name`, `click_value`, `site_money_unit`, `refer_earn_per`, `back_percent`, `min_pay`, `site_pay_method`, `max_refer_number`, `now_refer_number`, `back_number`, `site_status`, `site_category`, `refer_link`, `help_link`, `site_comment`, `site_time`) VALUES
(1, '快乐转转', 0.0015, '￥', 0.2, 0.5, 0.2, '支付宝', 9999, 4, 5, '金钻推荐', '国内点击', 'http://www.sharewz.com', 'http://www.sharewz.com', '注意推荐人为本站ID【easywzw】', '2010-3-23'),
(2, '51诚信币', 0, '￥', 0.5, 0.5, 1, '支付宝', 9999, 2, 0, '银钻推荐', '国内点击', 'http://www.sharewz.com', 'http://www.sharewz.com', '注意推荐人为本站ID【easywzw】', '2010-3-31'),
(7, '1', 1, '￥', 0.5, 1, 1, '1', 1, 1, 1, '金钻推荐', '国内点击', '11', '1', '1', '2010-3-31'),
(8, 'neobux', 0.01, '$', 0.5, 1, 2, 'paypal/alertpay', 116, 2, 0, '金钻推荐', '国外点击', 'http://www.sharewz.com', 'http://www.sharewz.com', '牛站-人人必做', NULL),
(9, 'neobux', 0.01, '$', 0.5, 1, 2, 'paypal/alertpay', 116, 2, 0, '金钻推荐', '国外点击', 'http://www.sharewz.com', 'http://www.sharewz.com', '牛站-人人必做', NULL),
(10, 'companybux', 0.01, '$', 0.5, 1, 2, 'paypal/alertpay', 116, 2, 0, '银钻推荐', '国外点击', 'http://www.sharewz.com', 'http://www.sharewz.com', '牛站-人人必做', NULL),
(11, 'abux', 0.01, '$', 0.5, 1, 2, 'paypal/alertpay', 116, 2, 0, '铜钻推荐', '国外点击', 'http://www.sharewz.com', 'http://www.sharewz.com', '牛站-人人必做', NULL),
(12, 'cbux', 0.01, '$', 0.5, 1, 2, 'paypal/alertpay', 116, 2, 0, '推荐', '国外点击', 'http://www.sharewz.com', 'http://www.sharewz.com', '牛站-人人必做', NULL),
(13, '第一调查网', 0.01, '$', 0.5, 1, 2, 'paypal/alertpay', 116, 2, 0, '金钻推荐', '调查', 'http://www.sharewz.com', 'http://www.sharewz.com', '牛站-人人必做', NULL),
(14, 'Ezy调查网', 0.01, '$', 0.5, 1, 2, 'paypal/alertpay', 116, 2, 0, '银钻推荐', '调查', 'http://www.sharewz.com', 'http://www.sharewz.com', '牛站-人人必做', NULL),
(15, '51诚信币', 0.01, '$', 0.5, 1, 2, 'paypal/alertpay', 116, 2, 0, '银钻推荐', '注册', 'http://www.sharewz.com', 'http://www.sharewz.com', '牛站-人人必做', NULL),
(16, '去赚啦', 0.01, '$', 0.5, 1, 2, 'paypal/alertpay', 116, 2, 0, '金钻推荐', '注册', 'http://www.sharewz.com', 'http://www.sharewz.com', '牛站-人人必做', NULL),
(17, '尖峰', 0.01, '$', 0.5, 1, 2, 'paypal/alertpay', 116, 2, 0, '金钻推荐', '投票', 'http://www.sharewz.com', 'http://www.sharewz.com', '牛站-人人必做', NULL),
(18, '小咪', 0.01, '$', 0.5, 1, 2, 'paypal/alertpay', 116, 2, 0, '银钻推荐', '投票', 'http://www.sharewz.com', 'http://www.sharewz.com', '牛站-人人必做', NULL),
(19, '新闻时报', 0.01, '$', 0.5, 1, 2, 'paypal/alertpay', 116, 2, 0, '银钻推荐', '冲浪', 'http://www.sharewz.com', NULL, '牛站-人人必做', NULL),
(20, '八趣', 0.01, '$', 0.5, 1, 2, 'paypal/alertpay', 116, 2, 0, '金钻推荐', '冲浪', 'http://www.sharewz.com', NULL, '牛站-人人必做', NULL),
(21, '发现宝', 0.01, '$', 0.5, 1, 2, 'paypal/alertpay', 116, 2, 0, '金钻推荐', '另类', 'http://www.sharewz.com', NULL, '牛站-人人必做', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `tb_buyref`
--

CREATE TABLE IF NOT EXISTS `tb_buyref` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `refnum` varchar(15) NOT NULL DEFAULT '',
  `sets` varchar(150) NOT NULL DEFAULT '',
  `customer` varchar(150) NOT NULL DEFAULT '',
  `amount` varchar(150) NOT NULL DEFAULT '',
  `refset` varchar(20) NOT NULL DEFAULT '',
  `pemail` varchar(150) NOT NULL DEFAULT '',
  `ip` varchar(15) NOT NULL DEFAULT '',
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 导出表中的数据 `tb_buyref`
--


-- --------------------------------------------------------

--
-- 表的结构 `tb_clickpack`
--

CREATE TABLE IF NOT EXISTS `tb_clickpack` (
  `id` int(11) NOT NULL DEFAULT '0',
  `item` varchar(150) NOT NULL DEFAULT '',
  `howmany` varchar(150) NOT NULL DEFAULT '',
  `price` varchar(150) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 导出表中的数据 `tb_clickpack`
--

INSERT INTO `tb_clickpack` (`id`, `item`, `howmany`, `price`) VALUES
(1, 'hits', '1000', '1');

-- --------------------------------------------------------

--
-- 表的结构 `tb_commendurl`
--

CREATE TABLE IF NOT EXISTS `tb_commendurl` (
  `url` varchar(300) NOT NULL,
  `name` varchar(50) NOT NULL,
  `type` varchar(20) DEFAULT NULL,
  `description` varchar(5000) DEFAULT NULL,
  `username` varchar(15) DEFAULT NULL,
  `status` int(2) DEFAULT NULL,
  `date` varchar(150) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=66 ;

--
-- 导出表中的数据 `tb_commendurl`
--

INSERT INTO `tb_commendurl` (`url`, `name`, `type`, `description`, `username`, `status`, `date`, `id`) VALUES
('http://www.baidu.com', 'baidu', '其他类', 'sousuo', 'admin', 2, '09-12-21 04:38', 65);

-- --------------------------------------------------------

--
-- 表的结构 `tb_common`
--

CREATE TABLE IF NOT EXISTS `tb_common` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `itemid` varchar(50) DEFAULT NULL,
  `value` varchar(150) DEFAULT NULL,
  `time` varchar(35) DEFAULT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 导出表中的数据 `tb_common`
--

INSERT INTO `tb_common` (`id`, `itemid`, `value`, `time`) VALUES
(1, 'leastpay', '0.1', '2010-3-26 03:49'),
(2, 'DomainName', '127.0.0.1:99', '2010-04-26'),
(3, 'ContinueClick', '0', '2010-04-26');

-- --------------------------------------------------------

--
-- 表的结构 `tb_config`
--

CREATE TABLE IF NOT EXISTS `tb_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item` varchar(15) NOT NULL DEFAULT '',
  `howmany` varchar(15) NOT NULL DEFAULT '',
  `price` varchar(150) NOT NULL DEFAULT '',
  `signupvalue` varchar(150) NOT NULL DEFAULT '',
  `hits_time` varchar(15) DEFAULT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 导出表中的数据 `tb_config`
--

INSERT INTO `tb_config` (`id`, `item`, `howmany`, `price`, `signupvalue`, `hits_time`) VALUES
(1, 'click', '1', '0.005', '', NULL),
(1, 'referalclick', '1', '0.0015', '', NULL),
(1, 'premiumclick', '1', '0.01', '', NULL),
(1, 'premiumreferalc', '1', '0.003', '', NULL),
(1, 'hits', '1000', '2.99', '', NULL),
(1, 'hits', '2000', '6', '', NULL),
(1, 'hits', '3000', '9', '', NULL),
(1, 'hits', '5000', '15', '', NULL),
(1, 'hits', '10000', '30', '', NULL),
(1, 'payment', '1', '0.3', '', NULL),
(1, 'upgrade', '1', '19.99', '', NULL),
(1, 'hits', '500', '1.49', '', NULL),
(1, 'hits', '20000', '60', '', NULL),
(1, 'hits', '30000', '30', '', NULL),
(1, 'hits', '50000', '150', '', NULL),
(1, 'hits', '100000', '300', '', NULL),
(1, 'cheat', '777', '0.1', '0.5', NULL);

-- --------------------------------------------------------

--
-- 表的结构 `tb_contact`
--

CREATE TABLE IF NOT EXISTS `tb_contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL DEFAULT '',
  `email` varchar(150) NOT NULL DEFAULT '',
  `topic` varchar(150) NOT NULL DEFAULT '',
  `subject` varchar(150) NOT NULL DEFAULT '',
  `comments` varchar(200) NOT NULL DEFAULT '',
  `ip` varchar(15) NOT NULL DEFAULT '',
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 导出表中的数据 `tb_contact`
--


-- --------------------------------------------------------

--
-- 表的结构 `tb_history`
--

CREATE TABLE IF NOT EXISTS `tb_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(150) NOT NULL DEFAULT '',
  `date` varchar(150) NOT NULL DEFAULT '',
  `amount` varchar(150) NOT NULL DEFAULT '0',
  `method` varchar(150) NOT NULL DEFAULT '',
  `status` varchar(150) NOT NULL DEFAULT '',
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- 导出表中的数据 `tb_history`
--

INSERT INTO `tb_history` (`id`, `user`, `date`, `amount`, `method`, `status`) VALUES
(1, 'admin', '20091217 07:41', '25', 'PayPal', 'Payment Sent'),
(2, 'admin', '20091217 07:41', '25', 'PayPal', 'Payment Sent'),
(3, 'admin', '20091221 05:15', '1.5', '支付宝', 'Payment Sent'),
(4, '111', '20091221 05:18', '2.2', '支付宝', 'Payment Sent'),
(5, 'admin', '20091221 05:26', '2', '支付宝', 'Payment Sent');

-- --------------------------------------------------------

--
-- 表的结构 `tb_messenger`
--

CREATE TABLE IF NOT EXISTS `tb_messenger` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sendfrom` varchar(11) NOT NULL DEFAULT '',
  `sendto` varchar(11) NOT NULL DEFAULT '',
  `date` varchar(35) NOT NULL DEFAULT '',
  `comments` varchar(150) NOT NULL DEFAULT '',
  `status` varchar(11) NOT NULL DEFAULT 'unread',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=33 ;

--
-- 导出表中的数据 `tb_messenger`
--

INSERT INTO `tb_messenger` (`id`, `sendfrom`, `sendto`, `date`, `comments`, `status`) VALUES
(23, 'refadmin', 'admin', '09-01-08 03:24', 'hola mi amor', 'read'),
(29, 'admin', 'lmmfgdao', '20-04-08 16:30', '&eacute ', 'unread'),
(30, 'admin', 'refadmin', '20-04-08 16:31', '阿道夫', 'unread'),
(31, 'admin', 'refadmin', '20-04-08 16:31', '阿道夫', 'unread'),
(32, 'admin', 'refadmin', '20-04-08 16:31', '上海市', 'unread');

-- --------------------------------------------------------

--
-- 表的结构 `tb_news`
--

CREATE TABLE IF NOT EXISTS `tb_news` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL,
  `url` char(100) DEFAULT NULL,
  `author` char(20) DEFAULT NULL,
  `date` char(150) NOT NULL,
  `counts` int(11) DEFAULT '1',
  `type` char(20) DEFAULT NULL,
  `origin` varchar(11) NOT NULL,
  `content` blob NOT NULL,
  `status` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 导出表中的数据 `tb_news`
--


-- --------------------------------------------------------

--
-- 表的结构 `tb_payme`
--

CREATE TABLE IF NOT EXISTS `tb_payme` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(150) NOT NULL DEFAULT '',
  `pasword` varchar(150) NOT NULL DEFAULT '',
  `email` varchar(150) NOT NULL DEFAULT '',
  `pemail` varchar(150) NOT NULL DEFAULT '',
  `country` varchar(150) NOT NULL DEFAULT '',
  `money` varchar(150) NOT NULL DEFAULT '',
  `ip` varchar(15) NOT NULL DEFAULT '',
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- 导出表中的数据 `tb_payme`
--

INSERT INTO `tb_payme` (`id`, `username`, `pasword`, `email`, `pemail`, `country`, `money`, `ip`) VALUES
(16, 'admin', 'Wj9WYgQ3ADNVMFRg', 'admin@wycy8.cn', 'admin@wycy8.cn', 'China', '2', '127.0.0.1');

-- --------------------------------------------------------

--
-- 表的结构 `tb_payproof`
--

CREATE TABLE IF NOT EXISTS `tb_payproof` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) DEFAULT NULL,
  `site_name` varchar(150) DEFAULT NULL,
  `pay_number` int(10) DEFAULT NULL,
  `now_pay_sum` double DEFAULT NULL,
  `all_pay_sum` float DEFAULT NULL,
  `pay_time` varchar(35) DEFAULT NULL,
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- 导出表中的数据 `tb_payproof`
--

INSERT INTO `tb_payproof` (`id`, `site_id`, `site_name`, `pay_number`, `now_pay_sum`, `all_pay_sum`, `pay_time`) VALUES
(1, 1, '快乐转转 ', 1, 1.01, 0, '10-03-23 08:34 '),
(2, 1, '快乐转转 ', 2, 2.01, 1.01, '10-03-23 08:35 '),
(3, 2, '51诚信币 ', 1, 2, 0, '10-04-01 08:55 '),
(4, 2, '51诚信币 ', 2, 1, 2, '10-04-01 08:56 '),
(5, 2, '51诚信币 ', 2, 1, 2, '10-04-01 08:57 '),
(6, 2, '51诚信币 ', 2, 1, 2, '10-04-01 08:57 '),
(7, 2, '51诚信币 ', 5, 2, 5, '10-04-01 08:57 '),
(8, 2, '51诚信币 ', 6, 3, 7, '10-04-01 09:00 '),
(9, 2, '51诚信币 ', 7, 5, 10, '10-04-01 09:01 ');

-- --------------------------------------------------------

--
-- 表的结构 `tb_refset`
--

CREATE TABLE IF NOT EXISTS `tb_refset` (
  `id` int(11) NOT NULL DEFAULT '0',
  `howmany` int(5) NOT NULL DEFAULT '0',
  `price` varchar(5) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 导出表中的数据 `tb_refset`
--

INSERT INTO `tb_refset` (`id`, `howmany`, `price`) VALUES
(4, 100, '25'),
(3, 50, '14'),
(1, 20, '6');

-- --------------------------------------------------------

--
-- 表的结构 `tb_signupads`
--

CREATE TABLE IF NOT EXISTS `tb_signupads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner` varchar(150) NOT NULL DEFAULT '',
  `paypal` varchar(150) NOT NULL DEFAULT '',
  `adname` varchar(150) NOT NULL DEFAULT '',
  `url` varchar(200) NOT NULL DEFAULT '',
  `adnum` varchar(150) NOT NULL DEFAULT '',
  `value` varchar(150) NOT NULL DEFAULT '',
  `instruction` varchar(250) NOT NULL DEFAULT '',
  `status` varchar(150) NOT NULL DEFAULT '',
  UNIQUE KEY `id_2` (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 导出表中的数据 `tb_signupads`
--

INSERT INTO `tb_signupads` (`id`, `owner`, `paypal`, `adname`, `url`, `adnum`, `value`, `instruction`, `status`) VALUES
(1, 'hilary', '11', '11', 'http://11.com', '50', '0.02', 'ddd', 'no');

-- --------------------------------------------------------

--
-- 表的结构 `tb_signupusers`
--

CREATE TABLE IF NOT EXISTS `tb_signupusers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(150) NOT NULL DEFAULT '',
  `adid` varchar(150) NOT NULL DEFAULT '',
  `owner` varchar(150) NOT NULL DEFAULT '',
  `adname` varchar(150) NOT NULL DEFAULT '',
  `value` varchar(150) NOT NULL DEFAULT '',
  `status` varchar(150) NOT NULL DEFAULT '',
  `regname` varchar(150) NOT NULL DEFAULT '',
  `reqdate` varchar(150) NOT NULL DEFAULT '',
  `paiddate` varchar(150) NOT NULL DEFAULT '',
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 导出表中的数据 `tb_signupusers`
--


-- --------------------------------------------------------

--
-- 表的结构 `tb_site`
--

CREATE TABLE IF NOT EXISTS `tb_site` (
  `id` varchar(11) NOT NULL DEFAULT '',
  `sitename` varchar(30) NOT NULL DEFAULT '',
  `sitepp` varchar(30) NOT NULL DEFAULT '',
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 导出表中的数据 `tb_site`
--

INSERT INTO `tb_site` (`id`, `sitename`, `sitepp`) VALUES
('1', '易网赚', 'easywzw@gmail.com');

-- --------------------------------------------------------

--
-- 表的结构 `tb_upgrade`
--

CREATE TABLE IF NOT EXISTS `tb_upgrade` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(150) NOT NULL DEFAULT '',
  `pemail` varchar(150) NOT NULL DEFAULT '',
  `email` varchar(150) NOT NULL DEFAULT '',
  `status` varchar(150) NOT NULL DEFAULT '',
  `date` varchar(150) NOT NULL DEFAULT '',
  `end` varchar(150) NOT NULL DEFAULT '',
  `ip` varchar(15) NOT NULL DEFAULT '',
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 导出表中的数据 `tb_upgrade`
--


-- --------------------------------------------------------

--
-- 表的结构 `tb_users`
--

CREATE TABLE IF NOT EXISTS `tb_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(15) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `ip` varchar(15) NOT NULL DEFAULT '',
  `email` varchar(150) NOT NULL DEFAULT '',
  `pemail` varchar(150) NOT NULL DEFAULT '',
  `referer` varchar(15) NOT NULL DEFAULT '',
  `country` varchar(150) NOT NULL DEFAULT '',
  `visits` varchar(150) NOT NULL DEFAULT '0',
  `referals` varchar(150) NOT NULL DEFAULT '0',
  `referalvisits` varchar(150) NOT NULL DEFAULT '0',
  `money` varchar(150) NOT NULL DEFAULT '0.00',
  `paid` varchar(150) NOT NULL DEFAULT '0.00',
  `joindate` varchar(150) NOT NULL DEFAULT '',
  `lastlogdate` varchar(150) NOT NULL DEFAULT '',
  `lastiplog` varchar(150) NOT NULL DEFAULT '',
  `account` varchar(150) NOT NULL DEFAULT '',
  `user_status` varchar(15) NOT NULL DEFAULT 'user',
  UNIQUE KEY `id_2` (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=243 ;

--
-- 导出表中的数据 `tb_users`
--

INSERT INTO `tb_users` (`id`, `username`, `password`, `ip`, `email`, `pemail`, `referer`, `country`, `visits`, `referals`, `referalvisits`, `money`, `paid`, `joindate`, `lastlogdate`, `lastiplog`, `account`, `user_status`) VALUES
(1, 'admin', 'Wj9WYgQ3ADNVMFRg', '127.0.0.1', 'admin@wycy8.cn', 'admin@wycy8.cn', '', 'China', '9', '4', '1', '2.035', '7.5', '1184512264', '1272245976', '127.0.0.1', 'VIP5', 'admin'),
(239, '123', 'Wj9WYgQ3ADNVMFRg', '', '', '', '', '', '0', '0', '0', '0.00', '0.00', '', '', '', 'VIP1', 'user'),
(240, '111', 'Wj9WYgQ3ADNVMFRg', '', '', '', '', '', '0', '0', '0', '0.00', '0.00', '', '1271668918', '127.0.0.1', 'VIP2', 'user'),
(241, 'tim', 'Wj9WYgQ3ADNVMFRg', '', '', '', '', '', '0', '0', '0', '0.00', '0.00', '', '1271668205', '127.0.0.1', 'VIP3', 'user'),
(237, 'hilary3210', 'Wj9WYgQ3ADNVMFRg', '127.0.0.1', 'ss@ss.com', 'ss@ss.com', '', '', '0', '1', '0', '5.6', '0.00', '1261035627', '1271899470', '127.0.0.1', '', 'user'),
(242, 'hilary', 'Uz4BNVVsVGIDY1RmV2w=', '127.0.0.1', 'yehaihua@126.com', 'yehaihua@126.com', 'hilary3210', '', '0', '0', '0', '0.00', '0.00', '1271901341', '1271901354', '127.0.0.1', '', 'user'),
(238, '123', 'Wj9WYgQ3ADNVMFRg', '127.0.0.1', 'ss@dfd.com', 'ss@dfd.com', 'admin', '', '0', '0', '0', '0', '2.2', '1261364802', '1271149950', '127.0.0.1', '', 'user');

-- --------------------------------------------------------

--
-- 表的结构 `users_online`
--

CREATE TABLE IF NOT EXISTS `users_online` (
  `visitor` varchar(15) NOT NULL DEFAULT '',
  `lastvisit` int(14) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 导出表中的数据 `users_online`
--

INSERT INTO `users_online` (`visitor`, `lastvisit`) VALUES
('127.0.0.1', 1272270923);
